/*
 * _8BITS_LCD.h
 *
 * Created: 31/07/2024 17:56:12
 *  Author: Luis Angel Velasquez
 */ 


#ifndef BITS_8_LCD_H_
#define BITS_8_LCD_H_


#define F_CPU 16000000
#include <avr/io.h>
#include <stdint.h>
#include <util/delay.h>


void init_8BITS_LCD(void);

void LCD_PORT(char a);

void LCD_SEND(char a);

void LCD_CAR(char c);

void LCD_TEXT(char *a);

void LCD_Shift_Right(void);

void LCD_Shift_Left(void);

void LCD_Set_Cursor(char c, char f);


#endif /* BITS_8_LCD_H_ */