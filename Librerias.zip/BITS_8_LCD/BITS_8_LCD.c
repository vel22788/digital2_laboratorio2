/*
 * _8BITS_LCD.c
 *
 * Created: 31/07/2024 17:56:00
 *  Author: Luis Angel Velasquez
 */ 

 #define F_CPU 16000000
 #include "BITS_8_LCD.h"
 #include <avr/io.h>
 #include <avr/delay.h>

void LCD_PORT(char a) {
	if (a & 1){
		//D0 = 1
		PORTD |= (1<<PORTD4);
		} else{
		//D0 =0
		PORTD &= ~(1<<PORTD4);
	}
	/****D1 *****/
	if (a & 2){
		//D1 =1
		PORTD |= (1<<PORTD5);
		} else{
		//D1=0
		PORTD &= ~(1<<PORTD5);
	}
	/****D2 *****/
	if (a & 4){
		//D0 = 1
		PORTD |= (1<<PORTD6);
		} else{
		//D0 =0
		PORTD &= ~(1<<PORTD6);
	}
	/****D3 *****/

	if (a & 8){
		//D1 =1
		PORTD |= (1<<PORTD7);
		} else{
		//D1=0
		PORTD &= ~(1<<PORTD7);
	}
	/****D4 *****/

	if (a & 16){
		//D0 = 1
		PORTB |= (1<<PORTB0);
		} else{
		//D0 =0
		PORTB &= ~(1<<PORTB0);
	}
	/****D5 *****/
	if (a & 32){
		//D1 =1
		PORTB |= (1<<PORTB1);
		} else{
		//D1=0
		PORTB &= ~(1<<PORTB1);
	}
	/****D6 *****/
	if (a & 64){
		//D0 = 1
		PORTB |= (1<<PORTB2);
		} else{
		//D0 =0
		PORTB &= ~(1<<PORTB2);
	}
	/****D7 *****/

	if (a & 128){
		//D1 =1
		PORTB |= (1<<PORTB3);
		} else{
		//D1=0
		PORTB &= ~(1<<PORTB3);
	}
}

 void LCD_SEND(char a) {
	 PORTD &= ~(1 << PORTD2); // RS=0
	 LCD_PORT(a);
	 PORTD |= (1 << PORTD3);  // EN=1
	 _delay_us(1);
	 PORTD &= ~(1 << PORTD3); // EN=0
	 _delay_ms(2);
 }
 
 void init_8BITS_LCD(void) {
	 DDRD |= (1 << DDD2) | (1 << DDD3) | (1 << DDD4) | (1 << DDD5) | (1 << DDD6) | (1 << DDD7);
	 PORTD = 0;
	 DDRB |= (1 << DDB0) | (1 << DDB1) | (1 << DDB2)|(1 << DDB3);
	 PORTB = 0;

	 _delay_ms(20);

	 // Inicializaci�n en 8 bits
	 LCD_SEND(0x38);
	 _delay_ms(5);
	 LCD_SEND(0x38);
	 _delay_ms(1);
	 LCD_SEND(0x38);
	 _delay_ms(1);

	 // Configuraci�n del LCD
	 
	 LCD_SEND(0x38); // Funci�n set
	 LCD_SEND(0x0C); // Display on, cursor off
	 LCD_SEND(0x01); // Clear display
	 _delay_ms(2);  // Esperar para el clear display
	 LCD_SEND(0x06); // Entry mode set
 }


 void LCD_CAR(char c) {
	 PORTD |= (1 << PORTD2);  // RS=1
	 LCD_PORT(c);
	 PORTD |= (1 << PORTD3);  // EN=1
	 _delay_us(1);
	 PORTD &= ~(1 << PORTD3); // EN=0
	 _delay_ms(2);
 }

 void LCD_TEXT(char * a) {
	 int i;
	 for (i = 0; a[i] != '\0'; i++)
	 LCD_CAR(a[i]);
 }

 void Lcd_Shift_Right(void) {
	 LCD_SEND(0x1C);
 }

 void Lcd_Shift_Left(void) {
	 LCD_SEND(0x18);
 }

 void LCD_Set_Cursor(char c, char f) {
	 char temp;
	 if (f == 1) {
		 temp = 0x80 + c - 1;
		 } else if (f == 2) {
		 temp = 0xC0 + c - 1;
	 }
	 LCD_SEND(temp);
 }